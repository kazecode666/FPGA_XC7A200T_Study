/////////////////////////////////////////////////////////////////////////////////
// Company       : �人о·��Ƽ����޹�˾
//                 http://xiaomeige.taobao.com
// Web           : http://www.corecourse.cn
// 
// Create Date   : 2023/01/31 00:00:00
// Module Name   : uart_ddr3_tft_hdmi
// Description   : ���ڴ�ͼDDR3����TFT����˫HDMI��ʾ
// 
// Dependencies  : 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
/////////////////////////////////////////////////////////////////////////////////

module ddr3_hdmi #(
  parameter DISP_WIDTH    = 1280,
  parameter DISP_HEIGHT   = 780
)
(
  //System clock reset
  input           clk50m        , //ϵͳʱ�����룬50MHz
  input           reset_n       , //��λ�ź�����
  //LED
  output     led           ,

  //hdmi1 interface
  output          hdmi1_clk_p   ,
  output          hdmi1_clk_n   ,
  output [2:0]    hdmi1_dat_p   ,
  output [2:0]    hdmi1_dat_n   ,
  output          hdmi1_oe      ,

  //DDR3 Interface
  // Inouts
  inout  [31:0]   ddr3_dq       ,
  inout  [3:0]    ddr3_dqs_n    ,
  inout  [3:0]    ddr3_dqs_p    ,
  // Outputs      
  output [14:0]   ddr3_addr     ,
  output [2:0]    ddr3_ba       ,
  output          ddr3_ras_n    ,
  output          ddr3_cas_n    ,
  output          ddr3_we_n     ,
  output          ddr3_reset_n  ,
  output [0:0]    ddr3_ck_p     ,
  output [0:0]    ddr3_ck_n     ,
  output [0:0]    ddr3_cke      ,
  output [0:0]    ddr3_cs_n     ,
  output [3:0]    ddr3_dm       ,
  output [0:0]    ddr3_odt      
);
//*********************************
//Internal connect
//*********************************
  //clock
  wire          pll_locked;
  wire          loc_clk50m;
  wire          loc_clk200m;
  wire          loc_clk33m;     //��ʵ��Ϊ׼
  wire          loc_clk165m;
  //reset
  wire          g_rst_p;
  //
  wire [15:0]   image_data;
  wire          image_data_valid;
  wire [15:0]   image_data_hcnt;
  wire [15:0]   image_data_vcnt;
  wire          image_data_hs;
  wire          image_data_vs;
  wire          frame_rx_done_flip;
  //wr_fifo Interface
  wire          wrfifo_clr;
  wire [15:0]   wrfifo_din;
  wire          wrfifo_wren;
  //rd_fifo Interface
  wire          rdfifo_clr;
  wire          rdfifo_rden;
  wire [15 :0]  rdfifo_dout;
  //mig Interface 
  wire          ddr3_rst_n;
  wire          ddr3_init_done;
  //tft
  wire          clk_disp;
  wire          disp_sof;
  //hdmi
  wire          pixelclk;
  wire          pixelclk5x;
  wire  [7:0]   disp_red;
  wire  [7:0]   disp_green;
  wire  [7:0]   disp_blue;
  wire          disp_hs;
  wire          disp_vs;
  wire          disp_de;

  assign ddr3_rst_n = pll_locked;  
  assign g_rst_p    = ~ddr3_init_done;
  assign led        = ddr3_init_done;

  pll pll
  (
    // Clock out ports
    .clk_out1 (loc_clk50m   ), // output clk_out1
    .clk_out2 (loc_clk200m  ), // output clk_out2
    // Status and control signals
    .resetn   (reset_n      ), // input reset
    .locked   (pll_locked   ), // output locked
    // Clock in ports
    .clk_in1  (clk50m       )  // input clk_in1
  );

  hdmi_pll hdmi_pll
   (
    // Clock out ports
    .clk_out1(loc_clk33m),     // output clk_out1
    .clk_out2(loc_clk165m),     // output clk_out2
    // Status and control signals
    .resetn(reset_n), // input reset
   // Clock in ports
    .clk_in1(clk50m)); 
        
    test_dat_gen #(
      .DISP_WIDTH    (DISP_WIDTH    ),
      .DISP_HEIGHT   (DISP_HEIGHT     ),
      .DATA_WIDTH    (16               )
    )
    test_dat_gen_inst(
      .clk           (loc_clk50m      ),
      .reset         (g_rst_p         ),
      .gen_en        (1'b1            ),
      .test_dat      (image_data       ),
      .test_dat_vaild(image_data_valid ),
      .test_dat_hs   (                ),
      .test_dat_vs   (                ),
      .test_dat_col  (                ),
      .test_dat_row  (                )
    );


  image_rx_ctrl#(
    .DISP_WIDTH        (DISP_WIDTH         ),
    .DISP_HEIGHT       (DISP_HEIGHT        )
  )
  image_rx_ctrl(
   .clk                (loc_clk50m         ),
   .reset_p            (g_rst_p            ),
   .image_data_valid   (image_data_valid   ),
   .image_data_hcnt    (image_data_hcnt    ),
   .image_data_vcnt    (image_data_vcnt    ),
   .image_data_hs      (image_data_hs      ),
   .image_data_vs      (image_data_vs      ),
   .frame_rx_done_flip (frame_rx_done_flip )
  );

  //TFT��Ļ��ʾ
  assign clk_disp = loc_clk33m;

  disp_driver #(
    .AHEAD_CLK_CNT ( 1 )
  )disp_driver
  (
    .ClkDisp     (clk_disp       ),
    .Rst_n       (~g_rst_p       ),

    .Data        (rdfifo_dout    ),
    .DataReq     (rdfifo_rden    ),

    .H_Addr      (               ),
    .V_Addr      (               ),
    .Disp_Sof    (disp_sof       ),

    .Disp_HS     (disp_hs         ),
    .Disp_VS     (disp_vs         ),
    .Disp_Red    (disp_red[7:3] ),
    .Disp_Green  (disp_green[7:2]  ),
    .Disp_Blue   (disp_blue[7:3]   ),

    .Disp_DE     (disp_de         ),
    .Disp_PCLK   (        )
  );

  assign wrfifo_clr  = g_rst_p;
  assign wrfifo_din  = image_data;
  assign wrfifo_wren = image_data_valid;
  assign rdfifo_clr  = disp_sof;

  ddr3_ctrl_2port #(
    .FIFO_DW            (16  ),
    .WR_BYTE_ADDR_BEGIN (0   ),
    .WR_BYTE_ADDR_END   (DISP_WIDTH*DISP_HEIGHT*2-1),
    .RD_BYTE_ADDR_BEGIN (0   ),
    .RD_BYTE_ADDR_END   (DISP_WIDTH*DISP_HEIGHT*2-1),
    .FIFO_ADDR_DEPTH    (64)
  )
  ddr3_ctrl_2port(
    //clock reset
    .ddr3_clk200m  (loc_clk200m   ),
    .ddr3_rst_n    (ddr3_rst_n    ),
    .ddr3_init_done(ddr3_init_done),
    //wr_fifo Interface
    .wrfifo_clr    (wrfifo_clr    ),
    .wrfifo_clk    (loc_clk50m    ),
    .wrfifo_wren   (wrfifo_wren   ),
    .wrfifo_din    (wrfifo_din    ),
    .wrfifo_full   (              ),
    .wrfifo_wr_cnt (              ),
    //rd_fifo Interface
    .rdfifo_clr    (rdfifo_clr    ),
    .rdfifo_clk    (clk_disp      ),
    .rdfifo_rden   (rdfifo_rden   ),
    .rdfifo_dout   (rdfifo_dout   ),
    .rdfifo_empty  (              ),
    .rdfifo_rd_cnt (              ),
    //DDR3 Interface
    // Inouts
    .ddr3_dq       (ddr3_dq       ),
    .ddr3_dqs_n    (ddr3_dqs_n    ),
    .ddr3_dqs_p    (ddr3_dqs_p    ),
    // Outputs      
    .ddr3_addr     (ddr3_addr     ),
    .ddr3_ba       (ddr3_ba       ),
    .ddr3_ras_n    (ddr3_ras_n    ),
    .ddr3_cas_n    (ddr3_cas_n    ),
    .ddr3_we_n     (ddr3_we_n     ),
    .ddr3_reset_n  (ddr3_reset_n  ),
    .ddr3_ck_p     (ddr3_ck_p     ),
    .ddr3_ck_n     (ddr3_ck_n     ),
    .ddr3_cke      (ddr3_cke      ),
    .ddr3_cs_n     (ddr3_cs_n     ),
    .ddr3_dm       (ddr3_dm       ),
    .ddr3_odt      (ddr3_odt      )
  );

  //HDMI��ʾ
  assign pixelclk   = loc_clk33m;
  assign pixelclk5x = loc_clk165m;
  assign hdmi1_oe   = 1'b1;
  //HDMI1
  dvi_encoder dvi_encoder1(
    .pixelclk    (pixelclk    ),
    .pixelclk5x  (pixelclk5x  ),
    .rst_p       (g_rst_p     ),
    .blue_din    (disp_blue   ),
    .green_din   (disp_green  ),
    .red_din     (disp_red    ),
    .hsync       (disp_hs     ),
    .vsync       (disp_vs     ),
    .de          (disp_de     ),
    .tmds_clk_p  (hdmi1_clk_p ),
    .tmds_clk_n  (hdmi1_clk_n ),
    .tmds_data_p (hdmi1_dat_p ),
    .tmds_data_n (hdmi1_dat_n )
  );


endmodule