`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/01/12 17:01:19
// Design Name: 
// Module Name: Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
    parameter LANE_NUM                 = 2      ;
    parameter CFG_DATA_NUM             = 357    ;
    parameter RESET_LOW_CNT_MAX        = 2000   ;
    parameter RESET_HIGH_CNT_MAX       = 2000000;
    parameter DELAY_MULT_FACTOR        = 20000   ;

module Top(
    input Clk,
    input Rst_n,
    input [1:0] key_in,
    output [1:0] Led,
    
    output reg [35:0] Gpio0,
    output reg [35:0] Gpio1,
    
    input uart_rx,
    output uart_tx,
    
  input         rgmii_rx_clk_i,
  input  [3:0]  rgmii_rxd,
  input         rgmii_rxdv,
  //eth_tx
  output        rgmii_tx_clk,
  output  [3:0] rgmii_txd,
  output        rgmii_txen,
  
  output        eth_rstn,  
  output        eth_mdc,
  output        eth_mdio,
  
    //MIPI�˿�      
    output                      MIPI_LP_Clk_p   ,
    output                      MIPI_LP_Clk_n   ,
    output  [LANE_NUM-1:0]      MIPI_LP_Data_p  ,
    output  [LANE_NUM-1:0]      MIPI_LP_Data_n  ,
    output                      MIPI_HS_Clk_p   ,
    output                      MIPI_HS_Clk_n   ,
    output  [LANE_NUM-1:0]      MIPI_HS_Data_p  ,
    output  [LANE_NUM-1:0]      MIPI_HS_Data_n  ,
    //LCD��λ�ͱ���
    output                      LCD_RSTN_PIN    ,   // lcd��λ��
    output                      LCD_BL_PIN      ,    // lcd�����

  //camera interface
    output reg [13:0]    camera_io,
   //hdmi interface
  output          hdmi_clk_p   ,
  output          hdmi_clk_n   ,
  output [2:0]    hdmi_dat_p   ,
  output [2:0]    hdmi_dat_n   ,
  output          hdmi_oe      ,

  //DDR3 Interface
  // Inouts
  inout  [31:0]   ddr3_dq       ,
  inout  [3:0]    ddr3_dqs_n    ,
  inout  [3:0]    ddr3_dqs_p    ,
  // Outputs      
  output [14:0]   ddr3_addr     ,
  output [2:0]    ddr3_ba       ,
  output          ddr3_ras_n    ,
  output          ddr3_cas_n    ,
  output          ddr3_we_n     ,
  output          ddr3_reset_n  ,
  output [0:0]    ddr3_ck_p     ,
  output [0:0]    ddr3_ck_n     ,
  output [0:0]    ddr3_cke      ,
  output [0:0]    ddr3_cs_n     ,
  output [3:0]    ddr3_dm       ,
  output [0:0]    ddr3_odt   
    );
    wire Check_ok;
    wire pwm;
    reg [25:0] cnt;
    wire ddr_led;
    
    assign Led[1] = ~(&key_in);
    assign Led[0] = ddr_led;

    always @(posedge Clk or negedge Rst_n)
    if(!Rst_n)
        cnt <= 0;
    else if(cnt == 50_000_000 -1)
        cnt <= 0;
    else
        cnt <= cnt + 1;        
    
   always @(posedge Clk or negedge Rst_n)
    if(!Rst_n)begin
        Gpio0 <= 0;
        Gpio1 <= 0;
        camera_io <= 0;
    end else if(cnt == 50_000_000 -1)begin
        Gpio0 <= ~Gpio0;
        Gpio1 <= ~Gpio1;
        camera_io <= ~camera_io;
    end
    
    uart_loopback(
    .Clk(Clk),
    .Rst_n(Rst_n),
    .uart_rx(uart_rx),
    
    .led(),
    .uart_tx(uart_tx)
 );
 
    eth_udp_loopback_rgmii eth_udp_loopback_rgmii(
  .reset_n(Rst_n),
  //eth_rx
  .rgmii_rx_clk_i(rgmii_rx_clk_i),
  .rgmii_rxd(rgmii_rxd),
  .rgmii_rxdv(rgmii_rxdv),
  //eth_tx
  .rgmii_tx_clk(rgmii_tx_clk),
  .rgmii_txd(rgmii_txd),
  .rgmii_txen(rgmii_txen),
  
  .eth_rstn(eth_rstn),  
  .eth_mdc(eth_mdc),
  .eth_mdio(eth_mdio),    
  //led
  .led()
);


mipi_dsi_lcd_color_bar  mipi_dsi_lcd_color_bar(
    .Ref_Clk(Clk)         ,   // 50M�ο�ʱ��
    .Reset_n(Rst_n)         ,   // ��λ
    
    .MIPI_LP_Clk_p(MIPI_LP_Clk_p)   ,
    .MIPI_LP_Clk_n(MIPI_LP_Clk_n)   ,
    .MIPI_LP_Data_p(MIPI_LP_Data_p)  ,
    .MIPI_LP_Data_n(MIPI_LP_Data_n)  ,
    .MIPI_HS_Clk_p(MIPI_HS_Clk_p)   ,
    .MIPI_HS_Clk_n(MIPI_HS_Clk_n)   ,
    .MIPI_HS_Data_p(MIPI_HS_Data_p)  ,
    .MIPI_HS_Data_n(MIPI_HS_Data_n)  ,
    
    .LCD_RSTN_PIN(LCD_RSTN_PIN)    ,   // lcd��λ��
    .LCD_BL_PIN(LCD_BL_PIN)      ,    // lcd�����
    .Frame_Done()          // ֡�����źţ�����������֡��
);
    
    ddr3_hdmi ddr3_hdmi (
    // System clock reset
    .clk50m        (Clk       ), // 50MHzϵͳʱ��
    .reset_n       (Rst_n      ), // ��λ�ź�

    // LED
    .led           (ddr_led          ),

    // HDMI1 interface
    .hdmi1_clk_p   (hdmi_clk_p  ),
    .hdmi1_clk_n   (hdmi_clk_n  ),
    .hdmi1_dat_p   (hdmi_dat_p  ),
    .hdmi1_dat_n   (hdmi_dat_n  ),
    .hdmi1_oe      (hdmi_oe     ),

    // DDR3 Interface
    .ddr3_dq       (ddr3_dq      ),
    .ddr3_dqs_n    (ddr3_dqs_n   ),
    .ddr3_dqs_p    (ddr3_dqs_p   ),
    .ddr3_addr     (ddr3_addr    ),
    .ddr3_ba       (ddr3_ba      ),
    .ddr3_ras_n    (ddr3_ras_n   ),
    .ddr3_cas_n    (ddr3_cas_n   ),
    .ddr3_we_n     (ddr3_we_n    ),
    .ddr3_reset_n  (ddr3_reset_n ),
    .ddr3_ck_p     (ddr3_ck_p    ),
    .ddr3_ck_n     (ddr3_ck_n    ),
    .ddr3_cke      (ddr3_cke     ),
    .ddr3_cs_n     (ddr3_cs_n    ),
    .ddr3_dm       (ddr3_dm      ),
    .ddr3_odt      (ddr3_odt     )
);

endmodule
