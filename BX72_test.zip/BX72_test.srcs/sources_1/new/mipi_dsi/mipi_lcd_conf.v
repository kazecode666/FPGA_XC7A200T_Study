`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/03/05 10:27:41
// Design Name: 
// Module Name: mipi_lcd_conf
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define D   #2

module mipi_lcd_conf # (
    parameter CFG_DATA_NUM = 298,
    parameter RESET_LOW_CNT_MAX  = 2000,     //��λʱ���͸�λ�ŵ�ʱ��,100us
    parameter RESET_HIGH_CNT_MAX = 2000000,  //��λʱ���߸�λ�ź�ȴ���ʱ��,100ms
    parameter DELAY_MULT_FACTOR  = 20000     //�Ե�ǰʱ��Ϊ��׼���ӳ�1ms����Ĵ���
) (
    input               TxClkEsc        ,   //����ģʽ����ʱ�ӣ�20MHz
    input               Reset_n         ,
    output reg  [8:0]   rom_addr        ,
    input       [7:0]   rom_data        ,
    output reg          LPDT_Request    ,   //LP���ݰ����ͣ�����ʱ����һ�η���LP���ݰ������Ͳ�����ֹ����
    output reg  [7:0]   LPDT_Data_ID    ,   //LPDT��Payload����    
    output reg  [15:0]  LPDT_WCount     ,   //LPDT�������ֽڳ��ȣ�0���̰�����0������
    output reg  [7:0]   LPDT_Data       ,   //LPDT��Payload����
    output reg          LPDT_Valid      ,   //LPDT��Payload������Ч
    input               LPDT_Ready      ,   //LPDT��Payload���ݻ���D1��D2���Ա�����
    input               LPDT_Busy       ,   //LPDT��æ
    output reg          LCD_RSTN_PIN    ,   //LCD��λ��
    output reg          LCD_Config_Done     //LCD�������
);


/*
    ʹ��״̬������ɳ�ʼ��

    S_Idel
    S_LCD_Reset         ����λ����100us(10us����)������λ��Ȼ�����ߣ��ȴ�100ms(50ms����)֮��λ���
    S_Cfg_Get           ��ȡROM��ȡǰ����������Data_ID+��ʱʱ��+����
    S_MIPI_Conf         ʹ��LPDT�ӿ�д��Data_ID+���ȣ�Ȼ����ݳ���ѡ���ȡ��һ�����ݻ��߽������䲢�ص�S_Cfg_Get
    S_MIPI_Delay        


*/



reg [23:0]Delay_Cnt;//һ��50ns,500ms��10000000
reg [7:0]Rom_READ_Cnt;
reg [23:0]Delay_Cnt_Max;
reg [7:0]Param_Num;


reg [5:0]SM_State;
localparam S_Idel       = 5'b0_0001;  
localparam S_LCD_Reset  = 5'b0_0010;  
localparam S_Cfg_Get    = 5'b0_0100;  
localparam S_MIPI_Conf  = 5'b0_1000;  
localparam S_MIPI_Delay = 5'b1_0000;  


always @(posedge TxClkEsc or negedge Reset_n) begin
    if(~Reset_n) begin
        SM_State <= `D S_Idel;
        rom_addr <= `D 9'd0;
        LPDT_Request <= `D 1'b0;
        LPDT_Data_ID <= `D 8'h00;
        LPDT_WCount  <= `D 16'h0000;
        LPDT_Data    <= `D 8'h00;
        LPDT_Valid   <= `D 1'b0;
        LCD_Config_Done <= `D 1'b0;
        LCD_RSTN_PIN <= `D 1'b1;
        Rom_READ_Cnt <= `D 8'd0;
        Param_Num <= `D 8'd0;
        Delay_Cnt <= `D 24'h00_00_00;
        Delay_Cnt_Max <= `D 24'h00_00_00;
    end
    else begin
        case (SM_State)
            S_Idel : begin
                if(~LCD_Config_Done) begin
                    SM_State <= `D S_LCD_Reset;
                end
                else begin
                    SM_State <= `D S_Idel;
                end
            end
            S_LCD_Reset : begin
                if(Delay_Cnt >= RESET_LOW_CNT_MAX + RESET_HIGH_CNT_MAX) begin    //��λ���
                    Delay_Cnt <= `D 24'd0;
                    LCD_RSTN_PIN <= `D 1'b1;
                    SM_State <= `D S_Cfg_Get;
                    rom_addr <= `D rom_addr + 9'd1;
                end
                else if(Delay_Cnt >= RESET_LOW_CNT_MAX) begin    //�������
                    Delay_Cnt <= `D Delay_Cnt + 24'd1;
                    LCD_RSTN_PIN <= `D 1'b1;
                    SM_State <= `D S_LCD_Reset;
                end
                else begin  //����
                    Delay_Cnt <= `D Delay_Cnt + 24'd1;
                    LCD_RSTN_PIN <= `D 1'b0;
                    SM_State <= `D S_LCD_Reset;
                end
            end
            S_Cfg_Get : begin
                if(Rom_READ_Cnt >= 8'd2) begin      //��������
                    Param_Num <= `D rom_data;
                    Rom_READ_Cnt <= `D 8'h00;
                    SM_State <= `D S_MIPI_Conf;
                end
                else if(Rom_READ_Cnt == 8'd1) begin //��ʱ(ms)
                    Delay_Cnt_Max <= `D rom_data * DELAY_MULT_FACTOR;
                    // Delay_Cnt_Max <= `D (rom_data << 14) + (rom_data << 11) + (rom_data << 10) + (rom_data << 9) + (rom_data << 5);
                    Rom_READ_Cnt <= `D Rom_READ_Cnt + 8'd1;
                    rom_addr <= `D rom_addr + 9'd1;
                    SM_State <= `D S_Cfg_Get;
                end
                else begin          //Data_ID
                    LPDT_Data_ID <= `D rom_data;
                    Rom_READ_Cnt <= `D Rom_READ_Cnt + 8'd1;
                    rom_addr <= `D rom_addr + 9'd1;
                    SM_State <= `D S_Cfg_Get;
                end
            end
            S_MIPI_Conf : begin
                //��ʼ����
                if(LPDT_Ready) begin
                    if((Param_Num == 8'd1) && (Rom_READ_Cnt == 8'd0)) begin
                        Rom_READ_Cnt <= `D Rom_READ_Cnt + 8'd1;
                        LPDT_Data    <= `D 8'h00;
                        LPDT_Valid   <= `D 1'b1;
                        SM_State <= `D S_MIPI_Conf;
                    end
                    else if(Rom_READ_Cnt >= Param_Num - 1) begin
                        Rom_READ_Cnt <= `D 8'd0;
                        LPDT_Data    <= `D rom_data;
                        rom_addr <= `D rom_addr + 9'd1;
                        LPDT_Valid   <= `D 1'b0;
                        LPDT_Request <= `D 1'b0;
                        SM_State <= `D S_MIPI_Delay;
                    end
                    else begin
                        Rom_READ_Cnt <= `D Rom_READ_Cnt + 8'd1;
                        rom_addr     <= `D rom_addr + 9'd1;
                        LPDT_Data    <= `D rom_data;
                        LPDT_Valid   <= `D 1'b1;
                        SM_State <= `D S_MIPI_Conf;
                    end
                end
                else if(Rom_READ_Cnt == 0) begin
                    LPDT_Request <= `D 1'b1;
                    LPDT_Data_ID <= `D LPDT_Data_ID;
                    if(Param_Num > 2)
                        LPDT_WCount  <= `D {8'h00,Param_Num};
                    else
                        LPDT_WCount  <= `D 16'd0;
                    LPDT_Data    <= `D rom_data;
                    LPDT_Valid   <= `D 1'b1;
                    SM_State <= `D S_MIPI_Conf;
                end
                else begin
                    LPDT_Request <= `D LPDT_Request;
                    LPDT_Data_ID <= `D LPDT_Data_ID;
                    LPDT_WCount  <= `D LPDT_WCount ;
                    if((Param_Num == 8'd1) && (Rom_READ_Cnt == 8'd1))
                        LPDT_Data    <= `D 8'h00;
                    else
                        LPDT_Data    <= `D rom_data;
                    LPDT_Valid   <= `D LPDT_Valid  ;
                    SM_State     <= `D S_MIPI_Conf;
                end

            end
            S_MIPI_Delay : begin
                if(Delay_Cnt >= Delay_Cnt_Max) begin
                    Delay_Cnt <= `D 24'd0;
                    if(rom_addr >= CFG_DATA_NUM) begin
                        SM_State <= `D S_Idel;
                        LCD_Config_Done <= `D 1'b1;
                    end
                    else begin
                        SM_State <= `D S_Cfg_Get;
                        rom_addr <= `D rom_addr + 9'd1;
                    end
                end
                else begin
                    Delay_Cnt <= `D Delay_Cnt + 24'd1;
                    SM_State <= `D S_MIPI_Delay;
                end
            end
            default: SM_State <= `D S_Idel;
        endcase
    end
end


endmodule
