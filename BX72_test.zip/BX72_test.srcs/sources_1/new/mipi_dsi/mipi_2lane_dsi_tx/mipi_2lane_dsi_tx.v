// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Thu Sep 11 08:51:00 2025
// Host        : DESKTOP-HAJLRPS running 64-bit major release  (build 9200)
// Command     : write_verilog -mode synth_stub
//               G:/MIPI/MIPI_LCD/ZYNQ_Prj/mipi_2lane_edf_files/project/mipi_dsi_lcd_color_bar_2lane/mipi_2lane_dsi_tx.v
// Design      : mipi_2lane_dsi_tx
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module mipi_2lane_dsi_tx(Reset_n, FIFO_Read_Cnt, FIFO_Read_Data, 
  FIFO_Rst_Busy, FIFO_Read_En, FIFO_Read_Clk, Frame_Start, Frame_Done, LPDT_Request, 
  LPDT_Data_ID, LPDT_WCount, LPDT_Data, LPDT_Valid, LPDT_Ready, LPDT_Busy, TxByteClkHS, TxDataHS, 
  TxRequestHS, TxReadyHS, TxClkEsc, TxRequestEsc, TxLpdtEsc, TxDataEsc, TxValidEsc, TxReadyEsc)
/* synthesis syn_black_box black_box_pad_pin="Reset_n,FIFO_Read_Cnt[15:0],FIFO_Read_Data[15:0],FIFO_Rst_Busy,FIFO_Read_En,FIFO_Read_Clk,Frame_Start,Frame_Done,LPDT_Request,LPDT_Data_ID[7:0],LPDT_WCount[15:0],LPDT_Data[7:0],LPDT_Valid,LPDT_Ready,LPDT_Busy,TxByteClkHS,TxDataHS[15:0],TxRequestHS[1:0],TxReadyHS[1:0],TxClkEsc,TxRequestEsc,TxLpdtEsc,TxDataEsc[7:0],TxValidEsc,TxReadyEsc" */;
  input Reset_n;
  input [15:0]FIFO_Read_Cnt;
  input [15:0]FIFO_Read_Data;
  input FIFO_Rst_Busy;
  output FIFO_Read_En;
  output FIFO_Read_Clk;
  input Frame_Start;
  output Frame_Done;
  input LPDT_Request;
  input [7:0]LPDT_Data_ID;
  input [15:0]LPDT_WCount;
  input [7:0]LPDT_Data;
  input LPDT_Valid;
  output LPDT_Ready;
  output LPDT_Busy;
  input TxByteClkHS;
  output [15:0]TxDataHS;
  output [1:0]TxRequestHS;
  input [1:0]TxReadyHS;
  input TxClkEsc;
  output TxRequestEsc;
  output TxLpdtEsc;
  output [7:0]TxDataEsc;
  output TxValidEsc;
  input TxReadyEsc;
endmodule
