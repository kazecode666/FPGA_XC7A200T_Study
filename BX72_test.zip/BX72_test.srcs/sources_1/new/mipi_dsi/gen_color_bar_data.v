`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/03/10 13:51:23
// Design Name: 
// Module Name: gen_color_bar_data
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module gen_color_bar_data(
    input                           Pixel_Clk       ,
    input                           Reset_n         ,
    output  reg     [23:0]          Pixel_Data      ,
    output  reg                     RGB_Write_En    ,
    input                           FIFO_Rst_Busy   ,
    input           [11 : 0]        FIFO_Write_Cnt   
);


reg [15:0]RGB_Data_Cnt;

//ÿ��1080��RGB���ݣ���Ϊ8������ ÿ135�����ػ�һ����ɫ
always @(posedge Pixel_Clk or negedge Reset_n) begin
    if(~Reset_n) begin
        RGB_Data_Cnt <= 16'd0;
        Pixel_Data <= 24'h000000;
        RGB_Write_En <= 1'b0;
    end
    else if(FIFO_Rst_Busy) begin
        RGB_Data_Cnt <= 16'd0;
        Pixel_Data <= 24'h000000;
        RGB_Write_En <= 1'b0;
    end
    else if(FIFO_Write_Cnt < 2048) begin
        RGB_Write_En <= 1'b1;
        if(RGB_Data_Cnt >= 1080-1) begin
            RGB_Data_Cnt <= 16'd0;
            Pixel_Data <= 24'h000000;
        end
        else if(RGB_Data_Cnt >= 945) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'h0000FF;   //��ɫ
        end
        else if(RGB_Data_Cnt >= 810) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'h000000;   //��ɫ
        end
        else if(RGB_Data_Cnt >= 675) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'hFF0000;   //��ɫ
        end
        else if(RGB_Data_Cnt >= 540) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
           Pixel_Data <= 24'hFF00FF;   //��� 
        end
        else if(RGB_Data_Cnt >= 405) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'h00FF00;   //��ɫ
        end
        else if(RGB_Data_Cnt >= 270) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'h00FFFF;   //��ɫ
        end
        else if(RGB_Data_Cnt >= 135) begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'hFFFFFF;   //��ɫ
        end
        else begin
            RGB_Data_Cnt <= RGB_Data_Cnt + 16'd1;
            Pixel_Data <= 24'hFFFF00;   //��ɫ           
        end
    end
    else begin
        RGB_Write_En <= 1'b0;
        RGB_Data_Cnt <= RGB_Data_Cnt;
        Pixel_Data <= Pixel_Data;
    end
end


endmodule
