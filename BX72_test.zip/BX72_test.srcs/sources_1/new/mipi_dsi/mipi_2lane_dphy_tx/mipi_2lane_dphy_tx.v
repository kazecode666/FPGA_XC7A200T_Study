// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Thu Sep 11 08:53:32 2025
// Host        : DESKTOP-HAJLRPS running 64-bit major release  (build 9200)
// Command     : write_verilog -mode synth_stub
//               G:/MIPI/MIPI_LCD/ZYNQ_Prj/mipi_2lane_edf_files/project/mipi_dsi_lcd_color_bar_2lane/mipi_2lane_dphy_tx.v
// Design      : mipi_2lane_dphy_tx
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module mipi_2lane_dphy_tx(MIPI_LP_Clk_p, MIPI_LP_Clk_n, MIPI_LP_Data_p, 
  MIPI_LP_Data_n, MIPI_HS_Clk_p, MIPI_HS_Clk_n, MIPI_HS_Data_p, MIPI_HS_Data_n, TxDDRClkHS_Q, 
  TxDDRClkHS_I, TxByteClkHS, TxDataHS, TxRequestHS, TxReadyHS, TxClkEsc, TxRequestEsc, TxLpdtEsc, 
  TxDataEsc, TxValidEsc, TxReadyEsc, Enable)
/* synthesis syn_black_box black_box_pad_pin="MIPI_LP_Clk_p,MIPI_LP_Clk_n,MIPI_LP_Data_p[1:0],MIPI_LP_Data_n[1:0],MIPI_HS_Clk_p,MIPI_HS_Clk_n,MIPI_HS_Data_p[1:0],MIPI_HS_Data_n[1:0],TxDDRClkHS_Q,TxDDRClkHS_I,TxByteClkHS,TxDataHS[15:0],TxRequestHS[1:0],TxReadyHS[1:0],TxClkEsc,TxRequestEsc,TxLpdtEsc,TxDataEsc[7:0],TxValidEsc,TxReadyEsc,Enable" */;
  output MIPI_LP_Clk_p;
  output MIPI_LP_Clk_n;
  output [1:0]MIPI_LP_Data_p;
  output [1:0]MIPI_LP_Data_n;
  output MIPI_HS_Clk_p;
  output MIPI_HS_Clk_n;
  output [1:0]MIPI_HS_Data_p;
  output [1:0]MIPI_HS_Data_n;
  input TxDDRClkHS_Q;
  input TxDDRClkHS_I;
  input TxByteClkHS;
  input [15:0]TxDataHS;
  input [1:0]TxRequestHS;
  output [1:0]TxReadyHS;
  input TxClkEsc;
  input TxRequestEsc;
  input TxLpdtEsc;
  input [7:0]TxDataEsc;
  input TxValidEsc;
  output TxReadyEsc;
  input Enable;
endmodule
