`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/03/07 08:49:37
// Design Name: 
// Module Name: 24b_to_Data_32b
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define D   #2

module D24b_to_D32b(
    input Clk,
    input Rst_n,
    input Conv_En,
    input [23:0]Data_24b,
    output reg [31:0]Data_32b,
    output reg Conv_Valid
);

reg [3:0]   Cnt;
reg [23:0]  Data_24b_R;

//λ��ת����rgb888ת32λ����4�Σ���3��
//д��������㹻һ��֮���ͣ�£�����һֱд
always @(posedge Clk or negedge Rst_n) begin
    if(~Rst_n) begin
        Cnt <= `D 4'd0;
        Data_32b <= `D 32'h00000000;
        Data_24b_R <= `D 24'h000000;
        Conv_Valid <= `D 1'b0;
    end
    else if(Conv_En) begin
        case (Cnt)
            4'd0: begin
                Cnt <= `D Cnt + 4'd1;
                Data_24b_R <= `D Data_24b;
                Data_32b <= `D 32'h00000000;
                Conv_Valid <= `D 1'b0;
            end
            4'd1: begin
                Cnt <= `D Cnt + 4'd1;
                Data_24b_R <= `D Data_24b;
                Data_32b <= `D {Data_24b[23:16],Data_24b_R[7:0],Data_24b_R[15:8],Data_24b_R[23:16]};//�ȷ�R���ȷ����ֽ�
                Conv_Valid <= `D 1'b1;
            end
            4'd2: begin
                Cnt <= `D Cnt + 4'd1;
                Data_24b_R <= `D Data_24b;
                Data_32b <= `D {Data_24b[15:8],Data_24b[23:16],Data_24b_R[7:0],Data_24b_R[15:8]};
                Conv_Valid <= `D 1'b1;
            end
            4'd3: begin
                Cnt <= `D 4'd0;
                Data_24b_R <= `D Data_24b;
                Data_32b <= `D {Data_24b[7:0],Data_24b[15:8],Data_24b[23:16],Data_24b_R[7:0]};//�ߵ��ֽڷ�ת
                Conv_Valid <= `D 1'b1;
            end
            default: Cnt <= `D 4'd0;
        endcase
    end
    else begin
        Cnt <= `D Cnt;
        Data_24b_R <= `D Data_24b_R;
        Data_32b <= `D Data_32b;
        Conv_Valid <= `D 1'b0;
    end
end


endmodule
